-Készítette: Birtalan Tibor József
-Neptun: TAJTNS
-tantárgy: ELTE IK 2023-24/2, Programozási nyelvek C++ 6.csoport
-gyak.vez: Fekete Anett

-összes állomány:
Card.h
Hand.h
Card.cpp
Hand.cpp
main.cpp

-futtatáshoz használt parancs: 
g++ *.cpp -Wall -o poker; ./poker

-önértékelés: 
Lehetett volna szebben is, de erre a célra megfelel a kód. ^^